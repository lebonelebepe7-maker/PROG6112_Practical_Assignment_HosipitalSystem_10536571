/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;

public class Inpatient extends Patient {
    private String wardNumber;

    public Inpatient(String patientId, String firstName, String lastName, int age, String gender, String medicalCondition, String wardNumber) {
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
    }

    public String getWardNumber() { return wardNumber; }
    public void setWardNumber(String wardNumber) { this.wardNumber = wardNumber; }

    @Override
    public String getDetails() {
        return super.getDetails() + " Ward No: " + wardNumber;
    }
}