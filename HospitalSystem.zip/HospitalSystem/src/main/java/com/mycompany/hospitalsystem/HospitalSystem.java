/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalsystem;

import java.util.Scanner;

public class HospitalSystem {
    private static final HospitalManager manager = new HospitalManager();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n===== MEDICARE HOSPITAL SYSTEM =====");
            System.out.println("1. Patient Management");
            System.out.println("2. Bed Management");
            System.out.println("3. Reports");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            
            String choice = scanner.nextLine();
            switch (choice) {
                case "1" -> patientManagementMenu();
                case "2" -> bedManagementMenu();
                case "3" -> reportsMenu();
                case "4" -> {
                    exit = true;
                    System.out.println("Exiting System. Good luck with your assignment!");
                }
                default -> System.out.println("Invalid selection. Please try again.");
            }
        }
    }

    private static void patientManagementMenu() {
        System.out.println("\n--- Patient Management ---");
        System.out.println("1. Register New Patient");
        System.out.println("2. Search Patient by ID");
        System.out.println("3. Update Patient Details");
        System.out.println("4. Delete Patient");
        System.out.println("5. Display All Registered Patients");
        System.out.print("Select choice: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1" -> registerPatientPrompt();
            case "2" -> {
                System.out.print("Enter Patient ID: ");
                String searchId = scanner.nextLine();
                Patient p = manager.searchPatient(searchId);
                if (p != null) {
                    System.out.println(p.getDetails());
                } else {
                    System.out.println("Patient not found.");
                }
            }
            case "3" -> {
                System.out.print("Enter Patient ID to update: ");
                String upId = scanner.nextLine();
                System.out.print("Enter New First Name: ");
                String fn = scanner.nextLine();
                System.out.print("Enter New Last Name: ");
                String ln = scanner.nextLine();
                System.out.print("Enter New Age: ");
                int age = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter New Gender: ");
                String gen = scanner.nextLine();
                System.out.print("Enter New Medical Condition: ");
                String cond = scanner.nextLine();
                
                boolean updated = manager.updatePatient(upId, fn, ln, age, gen, cond);
                if (updated) {
                    System.out.println("Patient details updated successfully.");
                } else {
                    System.out.println("Patient ID not found.");
                }
            }
            case "4" -> {
                System.out.print("Enter Patient ID to delete: ");
                String delId = scanner.nextLine();
                if (manager.deletePatient(delId)) {
                    System.out.println("Patient deleted successfully.");
                } else {
                    System.out.println("Patient ID not found.");
                }
            }
            case "5" -> manager.displayAllPatients();
            default -> System.out.println("Invalid option.");
        }
    }

    private static void registerPatientPrompt() {
        System.out.print("Enter Patient ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter Gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter Medical Condition: ");
        String condition = scanner.nextLine();
        System.out.println("Select Patient Category: 1. INPATIENT, 2. OUTPATIENT, 3. EMERGENCY");
        int catChoice = Integer.parseInt(scanner.nextLine());

        PatientCategory category;
        category = switch (catChoice) {
            case 1 -> PatientCategory.INPATIENT;
            case 2 -> PatientCategory.OUTPATIENT;
            default -> PatientCategory.EMERGENCY;
        };

        Patient newPatient;
        if (category == PatientCategory.INPATIENT) {
            System.out.print("Enter Ward Number: ");
            String wardNumber = scanner.nextLine();
            newPatient = new Inpatient(id, firstName, lastName, age, gender, condition, wardNumber);
        } else {
            newPatient = new Patient(id, firstName, lastName, age, gender, condition, category);
        }

        if (manager.registerPatient(newPatient)) {
            System.out.println("Patient registered successfully!");
        } else {
            System.out.println("Error: Duplicate Patient ID detected!");
        }
    }

    private static void bedManagementMenu() {
        System.out.println("\n--- Bed Management ---");
        System.out.println("1. Allocate Bed to Inpatient");
        System.out.println("2. Release Bed");
        System.out.println("3. Display Complete Ward Layout");
        System.out.println("4. Display Available Beds");
        System.out.println("5. Display Occupied Beds");
        System.out.print("Select choice: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1" -> {
                System.out.print("Enter Inpatient ID: ");
                String pId = scanner.nextLine();
                System.out.print("Enter Bed Code : ");
                String bedCode = scanner.nextLine();
                manager.allocateBed(pId, bedCode);
            }
            case "2" -> {
                System.out.print("Enter Bed Code to release: ");
                String rBed = scanner.nextLine();
                manager.releaseBed(rBed);
            }
            case "3" -> manager.displayWardLayout();
            case "4" -> manager.displayAvailableBeds();
            case "5" -> manager.displayOccupiedBeds();
            default -> System.out.println("Invalid option.");
        }
    }

    private static void reportsMenu() {
        System.out.println("\n--- Reports ---");
        manager.generateWardReport();
    }
}
