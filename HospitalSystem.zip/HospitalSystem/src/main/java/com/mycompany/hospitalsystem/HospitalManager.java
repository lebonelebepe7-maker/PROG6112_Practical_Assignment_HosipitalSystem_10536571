/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;

import java.util.ArrayList;

public class HospitalManager {
    private final ArrayList<Patient> patients = new ArrayList<>();
    private final String[][] wardLayout = new String[4][5]; // 4 x 5 layout for 20 beds

    public HospitalManager() {
        initializeWard();
    }

    private void initializeWard() {
        int count = 1;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                wardLayout[r][c] = String.format("B%02d", count++);
            }
        }
    }

    
    public boolean registerPatient(Patient patient) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patient.getPatientId())) {
                return false; 
            }
        }
        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    public boolean updatePatient(String patientId, String fn, String ln, int age, String gender, String condition) {
        Patient p = searchPatient(patientId);
        if (p != null) {
            p.setFirstName(fn);
            p.setLastName(ln);
            p.setAge(age);
            p.setGender(gender);
            p.setMedicalCondition(condition);
            return true;
        }
        return false;
    }

    public boolean deletePatient(String patientId) {
        Patient p = searchPatient(patientId);
        if (p != null) {
            
            for (int r = 0; r < 4; r++) {
                for (int c = 0; c < 5; c++) {
                    if (wardLayout[r][c].startsWith(patientId + ":")) {
                        int bedNum = (r * 5) + c + 1;
                        wardLayout[r][c] = String.format("B%02d", bedNum);
                    }
                }
            }
            patients.remove(p);
            return true;
        }
        return false;
    }

    public void displayAllPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }
        for (Patient p : patients) {
            System.out.println(p.getDetails());
        }
    }

    
    public boolean allocateBed(String patientId, String bedCode) {
        Patient p = searchPatient(patientId);
        if (p == null || p.getCategory() != PatientCategory.INPATIENT) {
            System.out.println("Allocation Failed: Only registered Inpatients can be allocated a bed.");
            return false;
        }

        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (wardLayout[r][c].equalsIgnoreCase(bedCode)) {
                    wardLayout[r][c] = patientId + ":" + bedCode;
                    System.out.println("Bed " + bedCode + " allocated to Patient " + patientId);
                    return true;
                } else if (wardLayout[r][c].equalsIgnoreCase(patientId + ":" + bedCode)) {
                    System.out.println("Allocation Failed: Bed is already occupied.");
                    return false;
                }
            }
        }
        System.out.println("Allocation Failed: Bed Code not found or already occupied.");
        return false;
    }

    public boolean releaseBed(String bedCode) {
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (wardLayout[r][c].endsWith(":" + bedCode)) {
                    int bedNum = (r * 5) + c + 1;
                    wardLayout[r][c] = String.format("B%02d", bedNum);
                    System.out.println("Bed " + bedCode + " released successfully.");
                    return true;
                }
            }
        }
        System.out.println("Release Failed: Bed was not occupied or invalid bed code.");
        return false;
    }

    public void displayWardLayout() {
        System.out.println("\nWard Layout (4x5):");
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                System.out.print(wardLayout[r][c] + "\t");
            }
            System.out.println();
        }
    }

    public int getOccupiedBedCount() {
        int occupied = 0;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (wardLayout[r][c].contains(":")) {
                    occupied++;
                }
            }
        }
        return occupied;
    }

    public void displayAvailableBeds() {
        System.out.print("Available Beds: ");
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (!wardLayout[r][c].contains(":")) {
                    System.out.print(wardLayout[r][c] + " ");
                }
            }
        }
        System.out.println();
    }

    public void displayOccupiedBeds() {
        System.out.print("Occupied Beds: ");
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                if (wardLayout[r][c].contains(":")) {
                    System.out.print(wardLayout[r][c] + " ");
                }
            }
        }
        System.out.println();
    }

    public void generateWardReport() {
        System.out.println("\n========== WARD REPORT ==========");
        System.out.println("All Registered Patients:");
        displayAllPatients();
        System.out.println("---------------------------------");
        displayAvailableBeds();
        displayOccupiedBeds();
        int totalPatients = patients.size();
        int occupied = getOccupiedBedCount();
        double occupancyPercentage = (occupied / 20.0) * 100;

        System.out.println("Total Registered Patients: " + totalPatients);
        System.out.println("Total Occupied Beds: " + occupied);
        System.out.println("Ward Occupancy Percentage: " + occupancyPercentage + "%");
        System.out.println("=================================");
    }

    
    public ArrayList<Patient> getPatients() { return patients; }
    public String[][] getWardLayout() { return wardLayout; }
}