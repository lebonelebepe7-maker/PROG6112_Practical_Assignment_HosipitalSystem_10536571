/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class HospitalManagerTest {
    private HospitalManager manager;

    @Before
    public void setUp() {
        manager = new HospitalManager();
    }

    @Test
    public void testRegisterPatient() {
        Patient p = new Patient("P001", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        assertTrue(manager.registerPatient(p));
        assertEquals(1, manager.getPatients().size());
    }

    @Test
    public void testSearchPatient() {
        Patient p = new Patient("P001", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        manager.registerPatient(p);
        Patient found = manager.searchPatient("P001");
        assertNotNull(found);
        assertEquals("John", found.getFirstName());
    }

    @Test
    public void testUpdatePatientDetails() {
        Patient p = new Patient("P001", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        manager.registerPatient(p);
        boolean updated = manager.updatePatient("P001", "Johnny", "Doe", 31, "Male", "Recovered");
        assertTrue(updated);
        assertEquals("Johnny", manager.searchPatient("P001").getFirstName());
    }

    @Test
    public void testDeletePatient() {
        Patient p = new Patient("P001", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        manager.registerPatient(p);
        assertTrue(manager.deletePatient("P001"));
        assertNull(manager.searchPatient("P001"));
    }

    @Test
    public void testAllocateBed() {
        Inpatient p = new Inpatient("P002", "Jane", "Smith", 25, "Female", "Surgery", "Ward 1");
        manager.registerPatient(p);
        assertTrue(manager.allocateBed("P002", "B01"));
    }

    @Test
    public void testReleaseBed() {
        Inpatient p = new Inpatient("P002", "Jane", "Smith", 25, "Female", "Surgery", "Ward 1");
        manager.registerPatient(p);
        manager.allocateBed("P002", "B01");
        assertTrue(manager.releaseBed("B01"));
    }

    @Test
    public void testPreventDuplicatePatientIDs() {
        Patient p1 = new Patient("P001", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P001", "Jack", "Smith", 40, "Male", "Fever", PatientCategory.OUTPATIENT);
        manager.registerPatient(p1);
        assertFalse(manager.registerPatient(p2));
    }

    @Test
    public void testPreventAllocatingAnOccupiedBed() {
        Inpatient p1 = new Inpatient("P001", "John", "Doe", 30, "Male", "Surgery", "W1");
        Inpatient p2 = new Inpatient("P002", "Jane", "Doe", 28, "Female", "Observation", "W1");
        manager.registerPatient(p1);
        manager.registerPatient(p2);
        manager.allocateBed("P001", "B01");
        assertFalse(manager.allocateBed("P002", "B01"));
    }

    @Test
    public void testPreventBedAllocationWhenAllBedsOccupied() {
        for (int i = 1; i <= 20; i++) {
            String id = "P" + i;
            String bedCode = String.format("B%02d", i);
            Inpatient inp = new Inpatient(id, "Test", "User", 30, "Male", "Stable", "W1");
            manager.registerPatient(inp);
            manager.allocateBed(id, bedCode);
        }
        Inpatient extra = new Inpatient("P21", "Extra", "User", 30, "Male", "Stable", "W1");
        manager.registerPatient(extra);
        assertFalse(manager.allocateBed("P21", "B01"));
    }

    @Test
    public void testSortPatientsBySurnameOrID() {
        Patient p1 = new Patient("P002", "Bob", "Zimmerman", 50, "Male", "Checkup", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P001", "Alice", "Adams", 22, "Female", "Checkup", PatientCategory.OUTPATIENT);
        manager.registerPatient(p1);
        manager.registerPatient(p2);
        
        manager.getPatients().sort((a, b) -> a.getLastName().compareToIgnoreCase(b.getLastName()));
        assertEquals("Adams", manager.getPatients().get(0).getLastName());
    }
}